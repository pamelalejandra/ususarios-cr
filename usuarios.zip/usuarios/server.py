from flask import Flask, render_template, request, redirect, session

from user import User
app = Flask(__name__)
app.secret_key = 'root'

@app.route('/')
def index():
    return render_template('crear.html')

@app.route('/crear_usuario', methods=["POST"])
def crear_usuario():

    data = {
        "fname":request.form['fname'],
        "lname":request.form['lname'],
        "email":request.form['email']
    }

    User.save(data)
    return redirect('/ver')

@app.route('/ver', methods=['GET'])
def ver ():
    print(request.form)
    users = User.get_all()
    print(users)
    return render_template('leer.html',users=users)

if __name__ == "__main__": 
    app.run(debug=True)